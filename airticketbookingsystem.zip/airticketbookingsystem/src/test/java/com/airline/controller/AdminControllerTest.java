package com.airline.controller;

import java.util.Date;

import javax.servlet.ServletException;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.airline.entity.User;
import com.airline.service.AdminService;
import com.airline.util.Converter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@WebMvcTest(AdminController.class)
public class AdminControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AdminService adminService;
	
	@MockBean
	Converter converter;
	
	String jwtToken="";
	
	private User user;
	
	@BeforeEach
	void setUp()
	{
		user = new User();
		user.setUserName("admin");
		user.setPassword("admin123");
		user.setRole("admin");
	}
	
	public String tokenCreation() throws ServletException
	{
		jwtToken=Jwts.builder().setSubject(user.getUserName()).claim("roles", user.getRole()).
				setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		return jwtToken;
	}
	
	@Test
	void saveAdminTest() throws Exception
	{
		String accessToken = tokenCreation();
		System.out.println(accessToken);
		
		String jsonString = new JSONObject()
				.put("id", 101)
				.put("name","admin")
				.put("email","admin@email.com")
				.put("userName","admin")
				.put("password","admin123")
				.put("role","admin")
				.toString();
		
		mockMvc.perform(MockMvcRequestBuilders.post("/api/createAdmin").
				contentType(MediaType.APPLICATION_JSON).content(jsonString).
				header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)).
				andExpect(MockMvcResultMatchers.status().isCreated());
	}
}
