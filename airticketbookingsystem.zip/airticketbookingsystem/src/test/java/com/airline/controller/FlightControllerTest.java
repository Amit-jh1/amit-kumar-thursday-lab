package com.airline.controller;

import java.util.Date;

import javax.servlet.ServletException;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.airline.entity.User;
import com.airline.service.FlightService;
import com.airline.util.FlightConverter;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@WebMvcTest(FlightController.class)
public class FlightControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private FlightService flightService;
	
	@MockBean
	FlightConverter flightConverter;
	
	String jwtToken="";
	
	private User user;
	
	@BeforeEach
	void setUp()
	{
		user = new User();
		user.setUserName("admin");
		user.setPassword("admin123");
		user.setRole("admin");
	}
	
	public String tokenCreation() throws ServletException
	{
		jwtToken=Jwts.builder().setSubject(user.getUserName()).claim("roles", user.getRole()).
				setIssuedAt(new Date()).signWith(SignatureAlgorithm.HS256, "secretkey").compact();
		return jwtToken;
	}
	
	@Test
	void saveFlightTest() throws Exception
	{
		String accessToken = tokenCreation();
		System.out.println(accessToken);
		
		String jsonString = new JSONObject()
				.put("id", 101)
				.put("totalSeats", 150)
				.put("availableSeats", 20)
				.put("travellerClass", "economy")
				.put("time", "13:00")
				.put("date", "2022-11-10")
				.put("source", "kolkata")
				.put("destination", "delhi")
				.toString();
		
		mockMvc.perform(MockMvcRequestBuilders.post("/api/saveFlight/admin").
				contentType(MediaType.APPLICATION_JSON).content(jsonString).
				header(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken)).
				andExpect(MockMvcResultMatchers.status().isCreated());
	}
}
